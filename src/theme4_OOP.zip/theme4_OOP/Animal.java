package theme4_OOP;

public abstract class Animal {
    public abstract void run(int d);
    public abstract void jump(double h);
    public abstract void swim(int s);
}
